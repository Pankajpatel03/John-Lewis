package CategoryLlist;

import PageObjects.ProductsList;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;

public class MyStepDefs extends Utils {

    ProductsList productsList = new ProductsList();

    @Given("^I am on the homepage$")
    public void i_am_on_the_homepage() {
        String URL = driver.getCurrentUrl();
        Assert.assertEquals(URL, "https://www.johnlewis.com/");
        System.out.println("User successfully Landed on Homepage");
    }

    @Then("^I accept cookies$")
    public void i_accept_cookies() {
        driver.findElement(By.cssSelector("[data-test='allow-all']")).click();
    }

    @When("^I select electricals category from the header$")
    public void i_select_electricals_category_from_the_header() {
        productsList.selectElectricals();
    }

    //Assertation of Category Page
    @Then("^I should see the list of electric products$")
    public void i_should_see_the_list_of_electric_products() {
        Assert.assertEquals(driver.findElement(By.cssSelector("[data-testid='category-page'] h1")).getText(), "ELECTRICALS");
    }

    @Then("I select Dishwasher category from the list$")
    public void i_select_Dishwasher_category_from_the_list() {
        productsList.selectDishwasherCategory();
        Assert.assertEquals(driver.findElement(By.cssSelector("[data-test='heading-term']")).getText(), "Dishwashers");
        System.out.println("I am able to see only Dishwasher products on the page");
    }

    @Then("^I should see the list of products from Dishwasher$")
    public void i_should_see_the_list_of_products_from_Dishwasher() {
        productsList.userAbleToSeeTheListOfProductsFromDishwasher();
        System.out.println("I am landed on Dishwasher products on the page");
    }
}
