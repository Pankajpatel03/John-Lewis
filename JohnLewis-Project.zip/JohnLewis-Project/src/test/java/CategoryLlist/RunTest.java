package CategoryLlist;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions (features = ".", tags = "@productList", dryRun = false, monochrome = true, plugin = {"pretty","html:target/cukeReport"})
public class RunTest {
}
