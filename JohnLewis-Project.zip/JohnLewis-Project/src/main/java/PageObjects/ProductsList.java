package PageObjects;

import CategoryLlist.LoadProperties;
import CategoryLlist.Utils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ProductsList extends Utils {

    LoadProperties loadprop = new LoadProperties(); // If need any data from data config properties

    private By _categoryElectricals = By.cssSelector("[data-testid='nav-electricals'] a");
    private By _selectDishwasher = By.cssSelector("[data-testid='nav-dishwashers']");

    public void selectElectricals (){
        clickOnElement(_categoryElectricals);
    }

    public void selectDishwasherCategory (){

        waitForElementVisible(_selectDishwasher,20);
        clickOnElement(_selectDishwasher);
    }

    // Printing all dishwasher products in console
    public void userAbleToSeeTheListOfProductsFromDishwasher () {

        List<WebElement> elementList = driver.findElements(By.cssSelector("#js-plp-body > div[data-test='component-grid-column']    "));
        for (int i = 0; i < elementList.size(); i++)
            System.out.println(elementList.get(i).getText());
    }
}
