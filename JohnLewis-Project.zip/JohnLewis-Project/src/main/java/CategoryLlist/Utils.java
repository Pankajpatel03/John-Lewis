package CategoryLlist;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.imageio.ImageIO;
import java.io.File;

public class Utils extends BasePage {

    //to click on element
    public static void clickOnElement(By by) {
        driver.findElement(by).click();
    }

    //Clear field and enter text
    public static void clearAndEnterText (By by,String text) {
        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(text);
    }
    public static void enterText (By by,String text) {
        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(text);
    }
    //Wait until element is clickable
    public static void waitForElementToBeClickable(By by){
        WebDriverWait wait=new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.elementToBeClickable(by));
    }

    //Wait for the element to visible
    public static void waitForElementVisible (By by, int time){
        WebDriverWait wait = new WebDriverWait (driver,time);
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));

    }

    public static void selectByVisibleText(By by,String text){
        new Select(driver.findElement(by)).selectByVisibleText(text);

    }
    public static void selectbyIndex(By by,int number)
    {
        new Select(driver.findElement(by)).selectByIndex(number);
    }

    public static void selectbyValue(By by,String value){
        new Select(driver.findElement(by)).selectByValue(value);
    }

    //Method to do expected = actual
    public static String getTextFromElement(By by)
    {
        String text = driver.findElement(by).getText();
        return text;
    }
    public static void assertTextMessage(String expected, By by) {
        try {
            String actual = getTextFromElement(by);
            Assert.assertEquals(expected, actual);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
